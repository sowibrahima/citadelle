package carte;


public interface Bien extends Carte {

    int getPrice();
    int getCharacter();
    int getSpecialPowerId();
    int getNumberOccur();
}
