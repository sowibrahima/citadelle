package carte;


import java.util.ArrayList;
import java.util.List;

public class Humain extends Joueur{

    public Humain(String name, String description, int coins) {
        super(name, description, true, new ArrayList<>(), coins);
    }
}
