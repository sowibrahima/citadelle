package carte;

public class Construction implements Bien{

    private int price, character, specialPowerId, numOccur;
    private String name, description;


    public Construction(String name, String description, int price, int character, int specialPowerId, int numOccur){
        this.name = name;
        this.description = description;
        this.price = price;
        this.character = character;
        this.specialPowerId = specialPowerId;
        this.numOccur = numOccur;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public int getPrice() {
        return this.price;
    }

    @Override
    public int getCharacter() {
        return this.character;
    }

    @Override
    public int getSpecialPowerId() {
        return this.specialPowerId;
    }

    @Override
    public int getNumberOccur() {
        return this.numOccur;
    }
}
