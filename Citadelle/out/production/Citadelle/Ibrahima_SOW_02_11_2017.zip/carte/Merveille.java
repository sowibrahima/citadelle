package carte;


public class Merveille extends Construction{

    public Merveille(String name, String description, int price, int specialPowerId, int numOccur){
        super(name, description, price, 0, specialPowerId, numOccur);
    }

}