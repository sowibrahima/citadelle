package carte;


import java.util.ArrayList;

public class Machine extends Joueur{

    int intelligence;

    public Machine(String name, String description, int coins,int intelligence) {
        super(name, description, false, new ArrayList<>(), coins);
        this.intelligence = intelligence;
    }
}
