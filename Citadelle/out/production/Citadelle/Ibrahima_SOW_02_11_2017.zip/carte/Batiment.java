package carte;


public class Batiment extends Construction{

    public Batiment(String name, String description, int price, int character, int numOccur){
        super(name, description, price, character, 0, numOccur);
    }

}
