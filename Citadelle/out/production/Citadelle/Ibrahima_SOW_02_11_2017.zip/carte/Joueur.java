package carte;


import java.util.Iterator;
import java.util.List;
import java.util.concurrent.locks.Condition;

public class Joueur implements Carte {

    private String name, description;
    private boolean isHuman;
    private List<Construction> constructions;
    private int coins;

    public Joueur(String name, String description, boolean isHuman, List<Construction> constructions, int coins){
        this.name = name;
        this.description = description;
        this.isHuman = isHuman;
        this.constructions = constructions;
        this.coins = coins;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    public boolean isHuman(){
        return this.isHuman;
    }

    public void addConstruction(Construction construction){
        this.constructions.add(construction);
    }

    public void removeConstruction(Construction construction){
        constructions.removeIf(constRemove -> constRemove.getName().equals(construction.getName()) && constRemove.getDescription().equals(construction.getDescription()));
    }

    public void addCoins(int coins){
        this.coins += coins;
    }

    public int getCoins(){
        return this.coins;
    }

    public void removeCoins(int coins){
        this.coins = this.coins>=coins?(this.coins-coins):0;
    }
}
