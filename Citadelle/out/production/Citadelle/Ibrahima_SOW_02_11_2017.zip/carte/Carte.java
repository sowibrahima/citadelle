package carte;


public interface Carte {

    public String getName();
    public String getDescription();
}
