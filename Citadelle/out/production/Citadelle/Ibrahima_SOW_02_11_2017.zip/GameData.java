import carte.Joueur;

import java.util.List;

public class GameData {

    List<Joueur> joueurs;

}
